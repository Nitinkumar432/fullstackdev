let pi=Math.PI;
console.log(pi);
console.log(Math.pow(10,5));
console.log(Math.ceil(2,5));

console.log(Math.floor(Math.random()*10+1));
console.log(Math.floor(Math.random()*100));



// 