let arr=[7,9,0,-2];
let cp=arr;

console.log(arr.splice(0,3));
console.log(cp.slice(-3));

// 2nd qu
let m;
if(m==null){
    console.log("blanlk hai ji");
}else{
    console.log('not');
}
let arrm=[5,6,4,4];
console.log(arrm.includes(33));




let a=20;

for(let i=1;i<a;i++){
    if(i%2==0){
        console.log(i);
    }
}



