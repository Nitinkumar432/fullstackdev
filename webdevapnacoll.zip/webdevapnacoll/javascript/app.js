console.log("hello");
let a=20;
let b=50;
console.log(a+b);
let milkprice=80;
console.log(`aacha milk ka price itna tha ${milkprice}`);
let next=0;
if (next>=20){
    console.log("age to bada hai");
}else if(next>=45){
    console.log('age hai ji med');
}
else{
    console.log("ok it sok");
}
df="nitin"
dfm=123
// console.log(df===dfm)
// console.log(alert("hii i am hewre"))
let at=prompt("enter  your name");
let bt=prompt("enter your father name");
console.log(`whole name is ${at} ${bt}`);

